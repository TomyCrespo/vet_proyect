from django.shortcuts import render, redirect
from django.http import HttpResponse
import sqlite3
import requests
from .forms import ClienteForm, MascotaForm, ConsultaForm
from .models import Cliente, Mascota, Consulta
# Create your views here.

def index(request):
    return render(request, "vet/index.html")

# def nuevo_cliente(request, template_name="vet/cliente_form.html"):
#     if request.method == "POST":
#         form = ClienteForm(request.POST)
#         if form.is_valid():
#             Cliente.objects.create(num_dni=form.cleaned_data["num_dni"],
#                                    nombre=form.cleaned_data["nombre"],
#                                    apellido=form.cleaned_data["apellido"],
#                                     direccion=form.cleaned_data["direccion"] )
#             return redirect("clientes")
            
#     else:
#         form = ClienteForm()
#     dato = {"form": form}
#     return render(request, template_name, dato)

# def nueva_mascota(request, template_name="vet/mascota_form.html"):
#     if request.method == "POST":
#         form = MascotaForm(request.POST)
#         if form.is_valid():
#            Mascota.objects.create(
#                                    nombre=form.cleaned_data["nombre"],
#                                    raza=form.cleaned_data["raza"],
#                                     categoria=form.cleaned_data["categoria"],
#                                      )
#            return redirect("mascotas")               
#     else:
#         form = MascotaForm()
#     dato = {"form": form}
#     return render(request, template_name, dato)

def nuevo_cliente(request, template_name="vet/cliente_form.html"):
    if request.method == "POST":
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect("clientes")                
    else:
        form = ClienteForm()
    dato = {"form": form}
    return render(request, template_name, dato)

def nueva_mascota(request, template_name="vet/mascota_form.html"):
    if request.method == "POST":
        form = MascotaForm(request.POST)
        if form.is_valid():
           form.save(commit=True)
           return redirect("mascotas")               
    else:
        form = MascotaForm()
    dato = {"form": form}
    return render(request, template_name, dato)

def clientes(request, template_name="vet/clientes.html"):
    clientes_p= Cliente.objects.all()
    dato = {"clientes": clientes_p}
    return render(request,template_name, dato)

def mascotas(request, template_name="vet/mascotas.html"):
    mascotas_p= Mascota.objects.all()
    dato = {"mascotas": mascotas_p}
    return render(request,template_name, dato)

def modificar_cliente(request, pk, template_name="vet/cliente_form.html"):
    cliente = Cliente.objects.get(id=pk)
    form = ClienteForm(request.POST or None, instance=cliente)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect("clientes")
    datos = {'form': form}
    return render(request, template_name, datos)

def eliminar_cliente(request, pk, template_name="vet/confirmar_eliminacion.html"):
    cliente = Cliente.objects.get(id=pk)
    if request.method == 'POST':
        cliente.delete()
        return redirect("clientes")
    dato = {"form":cliente.nombre, "tipo": "el cliente"}
    return render(request, template_name, dato)

def modificar_mascota(request, pk, template_name="vet/mascota_form.html"):
    mascota = Mascota.objects.get(id=pk)
    form = MascotaForm(request.POST or None, instance=mascota)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect("mascotas")
    datos = {'form': form}
    return render(request, template_name, datos)

def eliminar_mascota(request, pk, template_name="vet/confirmar_eliminacion.html"):
    mascota = Mascota.objects.get(id=pk)
    if request.method == 'POST':
        mascota.delete()
        return redirect("mascotas")
    dato = {"form":mascota.nombre, "tipo": "la mascota"}
    return render(request, template_name, dato)

def nueva_consulta(request, template_name="vet/consulta_form.html"):
    if request.method == "POST":
        form = ConsultaForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
            return redirect("consultas")                
    else:
        form = ConsultaForm()
    dato = {"form": form}
    return render(request, template_name, dato)

def consultas(request, template_name="vet/consultas.html"):
    consultas_p= Consulta.objects.all()
    dato = {"consultas": consultas_p}
    return render(request,template_name, dato)

def modificar_consulta(request, pk, template_name="vet/consulta_form.html"):
    consulta = Consulta.objects.get (id=pk)
    form = ConsultaForm(request.POST or None, instance=consulta)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect("consultas")
    dato = {'form':form}
    return render(request, template_name, dato)

def eliminar_consulta(request, pk, template_name="vet/confirmar_eliminacion.html"):
    consulta = Consulta.objects.get(id=pk)
    if request.method == 'POST':
        consulta.delete()
        return redirect("consultas")
    dato = {'form': consulta.fecha, 'tipo': "la consulta"}
    return render(request, template_name, dato)

