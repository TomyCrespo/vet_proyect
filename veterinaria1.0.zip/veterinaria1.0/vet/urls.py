from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("nuevo_cliente", views.nuevo_cliente, name="nuevo_cliente"),
    path("nueva_mascota", views.nueva_mascota, name="nueva_mascota"),
    path("clientes", views.clientes, name="clientes"),
    path("mascotas", views.mascotas, name="mascotas"),
    path("modificar_cliente/<int:pk>", views.modificar_cliente, name="modificar_cliente"),
    path("modificar_mascota/<int:pk>", views.modificar_mascota, name="modificar_mascota"),
    path("eliminar_cliente/<int:pk>", views.eliminar_cliente, name="eliminar_cliente"),
    path("eliminar_mascota/<int:pk>", views.eliminar_mascota, name="eliminar_mascota"),
    path("nueva_consulta", views.nueva_consulta, name="nueva_consulta"),
    path("consultas", views.consultas, name="consultas"),
    path("modificar_consulta/<int:pk>", views.modificar_consulta, name="modificar_consulta"),
    path("eliminar_consulta/<int:pk>", views.eliminar_consulta, name="eliminar_consulta")



]
