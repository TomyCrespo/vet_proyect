from django import forms
from django.forms import ModelForm
from .models import Cliente, Mascota, Consulta

# class ClienteForm(forms.Form):
#     num_dni = forms.IntegerField(label="DNI")
#     nombre = forms.CharField(label="Nombre", max_length=128)
#     apellido = forms.CharField(label="Apellido", max_length=128)
#     direccion = forms.CharField(label="Dirección", max_length=128)

class ClienteForm(ModelForm):
    class Meta:
        model = Cliente
        fields = "__all__"

# class MascotaForm(forms.Form):
#     nombre = forms.CharField(label="Nombre", max_length=128)
#     raza = forms.CharField(label="Raza", max_length=128)
#     categoria = forms.CharField(label="Categoria", max_length=128)

class MascotaForm(ModelForm):
    class Meta:
        model = Mascota
        fields = "__all__"

# class EnfermedadForm(ModelForm):
#     class Meta:
#         model = Enfermedad
#         fields = "__all__"

class ConsultaForm(ModelForm):
    class Meta:
        model= Consulta
        fields = "__all__"