from django.contrib import admin
from .import models
# Register your models here.

my_models = [models.Cliente, models.Mascota]

admin.site.register(my_models)

