from django.db import models


# Create your models here.

class Cliente(models.Model):
    num_dni = models.IntegerField("DNI")
    nombre = models.CharField("Nombre", max_length=128)
    apellido = models.CharField("Apellido", max_length=128)
    direccion = models.CharField("Dirección", max_length=128)

    def __str__(self):
        return "%s %s" % (self.nombre, self.apellido)

class Mascota(models.Model):
    nombre = models.CharField("Nombre", max_length=128)
    raza = models.CharField("Raza", max_length=128)
    categoria = models.CharField("Categoria", max_length=128)
    dueño = models.ForeignKey(Cliente, on_delete=models.PROTECT, null=True, blank=True)

    def __str__(self):
        return self.nombre

# class Enfermedad(models.Model):
#     nombre = models.CharField("Enfermedad", max_length=128)

class Consulta(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT)
    animal = models.ForeignKey(Mascota, on_delete=models.PROTECT)
    enfermedad = models.CharField("Enfermedad", max_length=200)
    fecha = models.DateField("fecha", )    
